"""CLI client to interact with FileServer."""
from __future__ import annotations
import socket, json, os, ssl
from typing import Optional
CHUNK = 64 * 1024

class Client:
    def __init__(self, host: str, port: int, use_tls: bool=False, verify: bool=True):
        self.host=host; self.port=port; self.sock: Optional[socket.socket]=None
        self.buf=b''; self.use_tls=use_tls; self.verify=verify

    def connect(self):
        raw = socket.create_connection((self.host, self.port))
        if self.use_tls:
            ctx = ssl.create_default_context()
            if not self.verify:
                ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
            self.sock = ctx.wrap_socket(raw, server_hostname=self.host)
        else:
            self.sock = raw
        _ = self.recv_line(); _ = self.recv_line()

    def send_line(self, line: str):
        assert self.sock
        self.sock.sendall((line.rstrip('\n') + '\n').encode())

    def recv_line(self) -> Optional[str]:
        assert self.sock
        while True:
            idx = self.buf.find(b'\n')
            if idx != -1:
                line = self.buf[:idx].decode(); self.buf = self.buf[idx+1:]; return line
            chunk = self.sock.recv(4096)
            if not chunk: return None
            self.buf += chunk

    def recv_exact(self, n: int) -> bytes:
        assert self.sock
        out = bytearray()
        while len(out) < n:
            chunk = self.sock.recv(min(65536, n - len(out)))
            if not chunk:
                raise ConnectionError('Server closed')
            out.extend(chunk)
        return bytes(out)

    def authenticate(self, username: str, password: str) -> bool:
        payload = json.dumps({'username': username, 'password': password})
        self.send_line(payload)
        resp = self.recv_line()
        return resp is not None and resp.startswith('OK')

    def list_files(self):
        self.send_line('LS'); resp = self.recv_line()
        if not resp: print('No response'); return
        if resp.startswith('OK '):
            items = json.loads(resp[3:])
            for it in items:
                if it['is_dir']: print(f"[DIR] {it['name']}")
                else: print(f"{it['name']} ({it['size']} bytes)")
        else:
            print('ERR', resp)

    def download(self, filename: str, dest: Optional[str]=None):
        dest = dest or filename
        self.send_line(f'GET {filename}'); resp = self.recv_line()
        if not resp: print('No response'); return
        if resp.startswith('OK '):
            size = int(resp.split(' ',1)[1])
            with open(dest,'wb') as f:
                remaining = size
                while remaining>0:
                    to_read = min(CHUNK, remaining)
                    chunk = self.recv_exact(to_read); f.write(chunk); remaining -= len(chunk)
            print('Downloaded', dest)
        else:
            print('ERR', resp)

    def upload(self, filepath: str):
        if not os.path.exists(filepath) or not os.path.isfile(filepath):
            print('Local file not found'); return
        size = os.path.getsize(filepath); fname = os.path.basename(filepath)
        self.send_line(f'PUT {fname} {size}')
        with open(filepath,'rb') as f:
            while True:
                chunk = f.read(CHUNK)
                if not chunk: break
                self.sock.sendall(chunk)
        resp = self.recv_line()
        if resp and resp.startswith('OK'): print('Upload succeeded')
        else: print('Upload failed', resp)

    def close(self):
        try:
            if self.sock: self.send_line('QUIT')
        except Exception:
            pass
        try:
            if self.sock: self.sock.close()
        except Exception:
            pass

if __name__ == '__main__':
    import argparse, getpass
    p = argparse.ArgumentParser()
    p.add_argument('--host', default='127.0.0.1')
    p.add_argument('--port', default=9000, type=int)
    p.add_argument('--tls', action='store_true')
    p.add_argument('--insecure', action='store_true')
    args = p.parse_args()
    client = Client(args.host, args.port, use_tls=args.tls, verify=not args.insecure)
    client.connect()
    user = input('username: ').strip()
    pw = getpass.getpass('password: ')
    if not client.authenticate(user, pw):
        print('Auth failed'); client.close(); exit(1)
    print('Authenticated. Type: ls | get <name> | put <localpath> | quit')
    try:
        while True:
            cmd = input('> ').strip()
            if not cmd: continue
            if cmd == 'ls': client.list_files()
            elif cmd.startswith('get '): client.download(cmd.split(' ',1)[1].strip())
            elif cmd.startswith('put '): client.upload(cmd.split(' ',1)[1].strip())
            elif cmd in ('quit','exit'): break
            else: print('Unknown command')
    finally:
        client.close()
