"""File server. Run directly as a script."""
from __future__ import annotations
import socket, threading, argparse, os, json, tempfile, ssl
from typing import Optional, Tuple
from .auth import build_demo_auth, BaseAuth
from .connection import SocketConnection
CHUNK = 64 * 1024

class FileServer:
    def __init__(self, host: str, port: int, root_dir: str, auth: BaseAuth,
                 certfile: Optional[str]=None, keyfile: Optional[str]=None):
        self.host = host; self.port = port; self.root = os.path.abspath(root_dir)
        os.makedirs(self.root, exist_ok=True)
        self.auth = auth; self.certfile = certfile; self.keyfile = keyfile
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.should_stop = threading.Event()

    def start(self):
        self.sock.bind((self.host, self.port)); self.sock.listen(8)
        print(f"Server listening on {self.host}:{self.port} root={self.root}")
        try:
            while not self.should_stop.is_set():
                client_sock, addr = self.sock.accept()
                try:
                    conn_sock = client_sock
                    if self.certfile and self.keyfile:
                        ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
                        ctx.load_cert_chain(certfile=self.certfile, keyfile=self.keyfile)
                        conn_sock = ctx.wrap_socket(client_sock, server_side=True)
                    conn = SocketConnection(conn_sock)
                    t = threading.Thread(target=self.handle_client, args=(conn, addr), daemon=True)
                    t.start()
                except Exception as e:
                    print('wrap error', e); client_sock.close()
        finally:
            self.sock.close()

    def stop(self):
        self.should_stop.set(); self.sock.close()

    def safe_path(self, filename: str) -> Optional[str]:
        target = os.path.abspath(os.path.join(self.root, filename))
        if os.path.commonpath([self.root, target]) != self.root:
            return None
        return target

    def handle_client(self, conn: SocketConnection, addr: Tuple[str,int]) -> None:
        try:
            conn.send_line('WELCOME'); conn.send_line('AUTHENTICATE')
            line = conn.recv_line()
            if not line:
                conn.close(); return
            try:
                creds = json.loads(line); username = creds.get('username'); password = creds.get('password')
            except Exception:
                conn.send_line('ERR bad auth payload'); conn.close(); return
            if not self.auth.authenticate(username, password):
                conn.send_line('ERR auth failed'); conn.close(); return
            conn.send_line('OK auth')
            while True:
                cmd = conn.recv_line()
                if cmd is None: break
                cmd = cmd.strip()
                if not cmd: continue
                parts = cmd.split(' ', 2); action = parts[0].upper()
                if action == 'LS':
                    try:
                        entries=[]
                        for name in os.listdir(self.root):
                            p = os.path.join(self.root, name)
                            entries.append({'name': name, 'size': os.path.getsize(p) if os.path.isfile(p) else None, 'is_dir': os.path.isdir(p)})
                        conn.send_line('OK ' + json.dumps(entries))
                    except Exception as e:
                        conn.send_line('ERR ' + str(e))
                elif action == 'GET' and len(parts)>=2:
                    fname = parts[1]; safe = self.safe_path(fname)
                    if not safe or not os.path.exists(safe) or not os.path.isfile(safe):
                        conn.send_line('ERR no such file'); continue
                    size = os.path.getsize(safe); conn.send_line(f'OK {size}')
                    with open(safe,'rb') as f:
                        while True:
                            chunk = f.read(CHUNK)
                            if not chunk: break
                            conn.send_all(chunk)
                elif action == 'PUT' and len(parts)>=3:
                    fname = parts[1]
                    try:
                        size = int(parts[2])
                    except:
                        conn.send_line('ERR invalid size'); continue
                    safe = self.safe_path(fname)
                    if not safe:
                        conn.send_line('ERR invalid filename'); continue
                    tmp_fd, tmp_path = tempfile.mkstemp(dir=self.root)
                    os.close(tmp_fd)
                    received=0
                    try:
                        with open(tmp_path,'wb') as f:
                            while received < size:
                                to_read = min(CHUNK, size - received)
                                chunk = conn.recv_exact(to_read)
                                f.write(chunk); received += len(chunk)
                        os.replace(tmp_path, safe); conn.send_line('OK uploaded')
                    except Exception as e:
                        try: os.unlink(tmp_path)
                        except: pass
                        conn.send_line('ERR ' + str(e))
                elif action == 'QUIT':
                    conn.send_line('OK bye'); break
                else:
                    conn.send_line('ERR unknown command')
        except ConnectionError:
            print('Connection closed by', addr)
        except Exception as e:
            print('handler error', e)
        finally:
            try: conn.close()
            except: pass

def main():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--host', default='0.0.0.0')
    p.add_argument('--port', type=int, default=9000)
    p.add_argument('--root', default='./shared')
    p.add_argument('--cert', default=None)
    p.add_argument('--key', default=None)
    args = p.parse_args()
    auth = build_demo_auth()
    server = FileServer(args.host, args.port, args.root, auth, certfile=args.cert, keyfile=args.key)
    try:
        server.start()
    except KeyboardInterrupt:
        server.stop()

if __name__ == '__main__':
    main()
