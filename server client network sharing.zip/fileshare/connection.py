"""Connection wrapper: BaseConnection and SocketConnection (plain or SSL)."""
from __future__ import annotations
import socket, threading
from typing import Optional, Tuple

class BaseConnection:
    def send_line(self, line: str) -> None: raise NotImplementedError
    def recv_line(self) -> Optional[str]: raise NotImplementedError
    def send_all(self, data: bytes) -> None: raise NotImplementedError
    def recv_exact(self, n: int) -> bytes: raise NotImplementedError
    def close(self) -> None: raise NotImplementedError

class SocketConnection(BaseConnection):
    def __init__(self, sock: socket.socket):
        self.sock = sock
        self.buf = b""
        self.lock = threading.Lock()

    def send_line(self, line: str) -> None:
        with self.lock:
            self.sock.sendall((line.rstrip('\n') + '\n').encode())

    def recv_line(self) -> Optional[str]:
        while True:
            idx = self.buf.find(b"\n")
            if idx != -1:
                line = self.buf[:idx].decode()
                self.buf = self.buf[idx+1:]
                return line
            chunk = self.sock.recv(4096)
            if not chunk:
                return None
            self.buf += chunk

    def send_all(self, data: bytes) -> None:
        with self.lock:
            self.sock.sendall(data)

    def recv_exact(self, n: int) -> bytes:
        out = bytearray()
        while len(out) < n:
            chunk = self.sock.recv(min(65536, n - len(out)))
            if not chunk:
                raise ConnectionError('Connection closed while receiving bytes')
            out.extend(chunk)
        return bytes(out)

    def close(self) -> None:
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass
        self.sock.close()
