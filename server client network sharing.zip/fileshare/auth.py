"""Authentication module: BaseAuth + InMemoryAuth.

Keep implementations Liskov-substitutable (can replace with DB-backed auth).
"""
from __future__ import annotations
import os, hashlib
from typing import Optional

class BaseAuth:
    """Interface for authentication providers."""
    def authenticate(self, username: str, password: str) -> bool:
        raise NotImplementedError

class InMemoryAuth(BaseAuth):
    """Simple in-memory auth using salt+sha256."""
    def __init__(self, users: Optional[dict]=None):
        self._users = users or {}

    def add_user(self, username: str, password: str) -> None:
        salt = os.urandom(16).hex()
        h = hashlib.sha256((salt + password).encode()).hexdigest()
        self._users[username] = { 'salt': salt, 'hash': h }

    def authenticate(self, username: str, password: str) -> bool:
        u = self._users.get(username)
        if not u:
            return False
        salt = u['salt']
        expected = u['hash']
        return hashlib.sha256((salt + password).encode()).hexdigest() == expected

def build_demo_auth() -> InMemoryAuth:
    auth = InMemoryAuth()
    auth.add_user('alice', 'password123')
    auth.add_user('bob', 'secret')
    return auth
